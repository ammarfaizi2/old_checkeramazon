<?php
<<<<<<< HEAD
$a = file_get_contents("Assets/empass it.txt");
$a = explode("\n", $a);
$b = '';
foreach ($a as $val) {
    $c = explode("|", $val);
    $b.="xxx|".$c[0]."|".$c[1]."\n";
}
file_put_contents("resik.txt", $b);
=======
$a = file_get_contents('results/sukses.txt');
$a = explode("\n",$a);

foreach($a as $q){
	foreach(json_decode($q,true) as $z){
		$zz = json_decode($z,true);
		print_r($zz);
	}
	echo '<br><br>';
	}
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
