<?php
     echo phpinfo();
<<<<<<< HEAD
=======
?>
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
