<head title="Pr1V"><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Pr1V | Amazon Account Checker</title>
<meta name="google-site-verification" content="lg1_yHbfcHo_r7ofAGXXxdGEjmPHAEy_ZDL_mP9vr9c"/>
<link rel="shortcut icon" href="https://upload.wikimedia.org/wikipedia/commons/4/46/Commons-logo.gif">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="https://upload.wikimedia.org/wikipedia/commons/4/46/Commons-logo.gif"/><meta http-equiv="expires" content="0">
<meta http-equiv="Content-Language" content="en-us">
<meta name="copyright" content="Pr1V">
<meta name="author" content="Edo Prayoga">
<script>
function sockupdate() {
        		$.ajax({
            		url: "socks.php",
            		dataType: "json",
            		type: "POST",
            		beforeSend: function (e) {
						$(".import-sock").html('Generating Socks5');
					},
            		data: "get_sock=1",
            		success: function(_0x1730x2a) {
                                $(".import-sock").html('Done!');
                		var _0x1730x21 = _0x1730x2a.socks;
                		$("#socks").val(_0x1730x21.replace(/\,/g, "\x0A"));
            		},
            		error: function(_0x1730x2a, _0x1730x38, _0x1730x39) {
                		if (_0x1730x38 == "error") {
                    		alert("Error! Please try again or contact admin");
                		};
            		}
        		});
    		}

setInterval(sockupdate,60000);



</script>
<meta name="distribution" content="Global">
<meta name="rating" content="General">
    <link href="css/bootstrap.css" rel="stylesheet">          
    <link href="css/bootstrap.min.css" rel="stylesheet">
           <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/bootstrap-theme.min.css" rel="stylesheet">
</head>
  <body>
<!-- Static navbar -->
<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only"> Toggle navigation </span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">Pr1V</a>
</div>
<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-right">
<li class="active">
<a href="/">Home</a></li>
</ul>
</nav>
</nav>
<div class="panel-heading">
<div class="panel panel-primary panelMove toggle panelRefresh panelClose">
                                    <!-- Start .panel -->
                                    <div class="panel-heading">
                                        <h4 class="panel-title">4m4z0n Account Checker  <span class="label label-primary">NEW</span></h4>
                                    </div>
                                    <div class="panel-body">
</style>
<div class="col-lg-9">
<label for="mailpass" class="control-label">Resource:</label>
<textarea name="mailpass" id="mailpass" class="form-control" rows="7" placeholder="email@domain.com|123123"></textarea>
<input name="delim" id="delim" style="text-align: center;display: none;width: 40px;margin-right: 5px;padding: 4px;" value="|" type="text" class="form-control">
<br>
<button type="button" class="btn btn-success" id="submit">Submit</button>
<button type="button" class="btn btn-danger" id="stop">Stop</button>&nbsp;
<img id="loading">
<span id="checkStatus" style="color:limegreen"></span>
</div>
<div class="col-xs-3">
<label for="socks" class="control-label">Socks5 <button type="button" class="btn btn-xs btn-primary import-sock">Get Socks</button></label>
<textarea name="socks" id="socks" placeholder="127.0.0.1:8080" class="form-control" rows="7"></textarea><br>
</div>
</div>
</div>
<div id="result">
<div class="panel panel-default"><div class="panel-heading">
<i class="icon-list-ul"></i>
<span>LIVE </span><span class="label label-success" id="acc_live_count" style="color:white">0</span>
</div><div class="panel-body"><div id="acc_live"></div></div></div></div>
<div class="panel panel-default"><div class="panel-heading">
<i class="icon-list-ul"></i>
<span>DIE </span><span class="label label-danger" id="acc_die_count" style="color:white">0</span>
</div><div class="panel-body"><div id="acc_die"></div></div></div>
<div class="panel panel-default"><div class="panel-heading">
<i class="icon-list-ul"></i>
<span>WRONG </span><span class="label label-danger" id="wrong_count" style="color:white">0</span>
</div><div class="panel-body"><div id="wrong"></div></div></div>
<div class="panel panel-default"><div class="panel-heading">
<i class="icon-list-ul"></i>
<span>SOCKS DIE </span><span class="label label-primary" id="bad_count" style="color:white">0</span>
</div><div class="panel-body"><div id="acc_bad"></div></div></div></div></div>


    <meta name="description" content="PayPal Account Checker">
    <meta name="author" content="Pr1V">
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="js/check.js"></script>
	<script type="text/javascript">
		function selectText(containerid) {
		if (document.selection) {
			var range = document.body.createTextRange();
			range.moveToElementText(document.getElementById(containerid));
			range.select();
			} else if (window.getSelection()) {
				var range = document.createRange();
				range.selectNode(document.getElementById(containerid));
				window.getSelection().removeAllRanges();
				window.getSelection().addRange(range);
			}
		}
	</script>
</head>
<body>