<?php
require __DIR__ . '/vendor/autoload.php';
use System\ActionHandler;

session_start();
define('BASEPATH', __DIR__);
define('ASSETS', BASEPATH.DIRECTORY_SEPARATOR.'Assets'.DIRECTORY_SEPARATOR);
define('RESULTS', BASEPATH.DIRECTORY_SEPARATOR.'results'.DIRECTORY_SEPARATOR);
$app = new ActionHandler();
$app->run();
