<?php
function check_exp($cc)
{
    $today = getdate();
    if ($cc['year']+0 < $today['year']+0) {
        return false;
    }
    if ($cc['year']+0 == $today['year']+0) {
        if ($cc['mon']+0 < $today['mon']+0) {
            return false;
        }
    }
    return true;
}
function isEmail($email)
{
    if (!preg_match("/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$/i", $email)) {
        return false;
    }
    return true;
}
function get_char($str, $sl)
{
    $str = strip_tags($str);
    $mang = explode(" ", $str);
    $chuoi = "";
    for ($i=0;$i<$sl;$i++) {
        $chuoi .= $mang[$i]." ";
    }
    return trim($chuoi);
}
function getsock($socks)
{
    preg_match("/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}[:|-\s\/]\d{1,7}/", $socks, $s);
    return $s[0];
}
function value($s, $from, $to)
{
    $s = explode($from, $s);
    $s = explode($to, $s[1]);
    return $s[0];
}
function get_string_between($string, $start, $end)
{
    $string = " ".$string;
    $ini = strpos($string, $start);
    if ($ini == 0) {
        return "";
    }
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}
function right($value, $count)
{
    return substr($value, ($count*-1));
}
function left($string, $count)
{
    return substr($string, 0, $count);
}
function test($vao)
{
    if (is_numeric($vao)) {
        return 1;
    }
    return 0;
}
function getStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
function inStr($s, $as)
{
    $s = strtoupper($s);
    if (!is_array($as)) {
        $as=array($as);
    }
    for ($i=0;$i<count($as);$i++) {
        if (strpos(($s), strtoupper($as[$i]))!==false) {
            return true;
        }
    }
    return false;
}
function get_string($string, $start, $end)
{
    $string = " ".$string;
    $ini = strpos($string, $start);
    if ($ini == 0) {
        return "";
    }
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}
function roundup($a)
{
    $b = explode(".", $a);
    if ($b[1] + 0 > 0) {
        return $b[0]+1;
    }
    return $b[0]+0;
}
function curl($url, $var = null)
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_TIMEOUT, 25);
    if ($var != null) {
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
    }
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
function getSztr($string, $start, $end)
{
    $str = explode($start, $string, 2);
    $str = explode($end, $str[1], 2);
    return $str[0];
}
function socker()
{
    $domain = array("http://www.vipsocks24.net","http://www.live-socks.net");
    $rand = rand(0, 1);
    $curl = curl($domain[$rand]);
    $potong = getSztr($curl, "<h3 class='post-title entry-title' itemprop='name'>", "</h3>");
    $potong_lagi = getSztr($potong, "<a href='", "'");
    $page = curl($potong_lagi);
    $socks = getSztr($page, ' wrap="hard">', '</textarea>');
    $socks = explode("\n", $socks);
    unset($socks[count($socks)-1]);
    return $socks;
}
