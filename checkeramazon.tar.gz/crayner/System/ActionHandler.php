<?php
namespace System;

require __DIR__ . '/Helper/FuncPack.php';
class ActionHandler
{
    private $assets;
    public function __construct()
    {
        $this->assets = array();
        $this->sockspos = 0;
    }
    private function get_assets()
    {
        $scan = scandir(ASSETS);
        unset($scan[0], $scan[1]);
        foreach ($scan as $val) {
            $x = explode("\n", file_get_contents(ASSETS.$val));
            is_dir(RESULTS.$val) or mkdir(RESULTS.$val);
            foreach ($x as $a) {
                $a = explode('|', $a, 4);
                isset($a[1], $a[2]) and $this->assets[$val][] = array($a[1],$a[2]);
            }
        }
    }
    private function gen_socks()
    {
        print PHP_EOL.PHP_EOL."Mendownload Socks...".PHP_EOL.PHP_EOL;
        $socks = array_merge(socker());
        $socks = array_filter($socks);
        $socks = array_unique($socks);
        $this->socks = $socks;
        $this->ctsocks = count($socks);
        print PHP_EOL."Berhasil mendownload ".$this->ctsocks." socks !".PHP_EOL.PHP_EOL;
    }
    private function check_socks()
    {
        if ($this->sockspos>=$this->ctsocks) {
            $this->sockspos = 0;
            $this->gen_socks();
        }
    }
    public function run()
    {
        $this->get_assets();
        $this->gen_socks();
        foreach ($this->assets as $key => $pal) {
            // buka file
            $this->open($key);

            foreach ($pal as $val) {
                print PHP_EOL.PHP_EOL."Sedang ngecek : ".$val[0]." | ".$val[1].PHP_EOL;
                print "===================================================================".PHP_EOL;
                $this->check_socks();
                $cek = json_decode(CheckerHandler::run(trim($val[0]), trim($val[1]), trim($this->socks[$this->sockspos])), true);
                print $cek['error']." | ".$cek['msg'].PHP_EOL;
                // CEK 1
                if ($cek['error']==3 and strpos($cek['msg'], "Captcha")===false) {
                    do {
                        $this->check_socks();
                        $this->sockspos++;
                        $cek = json_decode(CheckerHandler::run(trim($val[0]), trim($val[1]), trim($this->socks[$this->sockspos])), true);
                        print $cek['error']." | ".$cek['msg'].PHP_EOL;
                    } while ($cek['error']==3 and strpos($cek['msg'], "Captcha")===false);
                }

                // CEK 2
                if (strpos($cek['msg'], "LIVE")!==false) {
                    if (strpos($cek['msg'], "Can't")!==false) {
                        $this->sockspos++;
                    }
                    $this->sukses(array($val[0],$val[1],$cek['msg']));
                } elseif (strpos($cek['msg'], "Captcha")!==false) {
                    $this->sockspos++;
                    $this->captcha(array($val[0],$val[1],$cek['msg']));
                } else {
                    $this->gagal(array($val[0],$val[1],$cek['msg']));
                }
                print $cek['error']." | ".$cek['msg'].PHP_EOL;
                $this->log(array($val[0],$val[1],$cek['msg']));
            }

            // tutup file
            $this->close();
        }
    }
    private function open($file)
    {
        $this->success_file = fopen(RESULTS.$file.'/sukses.txt', 'a');
        $this->gagal_file   = fopen(RESULTS.$file.'/die.txt', 'a');
        $this->captcha_file = fopen(RESULTS.$file.'/captcha.txt', 'a');
        $this->logs_file    = fopen(RESULTS.$file.'/logs.txt', 'a');
    }
    private function close()
    {
        fclose($this->success_file);
        fclose($this->gagal_file);
        fclose($this->captcha_file);
        fclose($this->logs_file);
    }
    private function sukses($data)
    {
        fwrite($this->success_file, json_encode($data)."\n");
    }
    private function gagal($data)
    {
        fwrite($this->gagal_file, json_encode($data)."\n");
    }
    private function captcha($data)
    {
        fwrite($this->captcha_file, json_encode($data)."\n");
    }
    private function log($data)
    {
        fwrite($this->logs_file, json_encode($data)."\n");
    }
}
